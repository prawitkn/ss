<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GradingGroup extends Model
{
    //
}
