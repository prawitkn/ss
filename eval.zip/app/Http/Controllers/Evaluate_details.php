<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Evaluate_details extends Controller
{
    //
}
