<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User_roles;

class UserRoleController extends Controller
{
    //
}
