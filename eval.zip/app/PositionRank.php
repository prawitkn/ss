<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PositionRank extends Model
{
    //
}
