<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Evaluate_details extends Model
{
    //
}
