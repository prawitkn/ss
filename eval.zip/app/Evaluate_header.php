<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Evaluate_header extends Model
{
    //
}
